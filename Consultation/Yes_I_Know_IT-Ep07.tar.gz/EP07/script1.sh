#!/bin/bash

echo Hello, I\'m the first script
