#!/bin/bash

cat << EOF
Hello, I'm the second script
EOF
